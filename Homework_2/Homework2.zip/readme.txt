Adjust the desired File by inputting the file path in the first line or two of the .m file
Figures Should be outputted.