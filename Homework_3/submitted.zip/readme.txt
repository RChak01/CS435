Ensure that this .m file is in same path as circles1.gif. 
If different file is tested, simply change route of the circles1.path on line 136