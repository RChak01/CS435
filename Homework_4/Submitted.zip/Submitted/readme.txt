Part 2 Width and Height can be adjusted through variables on lines 8-9
Change image file the project by changing line 2
Video File name can be changed in line 144
Once Valid File is given, all figures should output and video should be saved locally